let countingDown = true;
let timer = 10;
let video;
let faceapi;
let detections = [];

function setup() {
  createCanvas(windowWidth, windowHeight);

  let constraints = {
    audio: false,
    video: {
      facingMode: {
        exact: "user"
      }
    }
  };

  video = createCapture(constraints, function() {
    console.log('video is ready');
  });
  video.hide();

  // Initialize faceapi model
  const faceOptions = {
    withLandmarks: true,
    withDescriptors: false,
  };
  faceapi = ml5.faceApi(video, faceOptions, onFaceModelReady);
}

function onFaceModelReady() {
  console.log("Face Model Loaded!");
  faceapi.detect(gotFaces);
}

function gotFaces(error, result) {
  if (error) {
    console.error(error);
    return;
  }
  detections = result;
  faceapi.detect(gotFaces);
}

function draw() {
  background(220);
  image(video, 0, 0);

  if (countingDown) {
    fill(230, 0, 0);
    textSize(10);
    text("find something circular", windowWidth/10, windowHeight/10);
    fill(230, 0, 0);
    textSize(100);
    text(timer, windowWidth/2, windowHeight/2);

    if (frameCount % 20 == 0) {
      timer--;
    }

    if (timer == 0) {
      countingDown = false;
    }
  } else {
    video.pause();

    // Drawing the red circle around detected face
    noFill();
    stroke(230, 0, 0);
    strokeWeight(2);
    for (let i = 0; i < detections.length; i++) {
      let alignedRect = detections[i].alignedRect;
      circle(alignedRect._box._x + alignedRect._box._width / 2, alignedRect._box._y + alignedRect._box._height / 2, alignedRect._box._width);
    }

    if (frameCount % 20 == 0) {
      timer++;
    }

    if (timer == 10) {
      countingDown = true;
      video.loop();  // Restart the video when timer is reset
    }
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

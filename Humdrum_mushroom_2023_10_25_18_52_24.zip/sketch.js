let img;
let video;
let faceapi;
let detections = [];

function preload() {
  img = loadImage("assets/cat.jpg"); // Replace with your image path
}

function setup() {
  createCanvas(400, 400);

  // Setup camera capture
  video = createCapture(VIDEO);
  video.size(width, height);
  video.hide();

  const detectionOptions = {
    withLandmarks: true,
    withDescriptors: false,
  };

  // Load face-api model
  faceapi = ml5.faceApi(video, detectionOptions, modelLoaded);
}

function modelLoaded() {
  console.log("FaceAPI Model Loaded!");
  faceapi.detect(gotResults);
}

function gotResults(err, result) {
  if (err) {
    console.log(err);
    return;
  }
  detections = result;
  faceapi.detect(gotResults);
}

function draw() {
  background(220);

  image(video, 0, 0, width, height);

  if (detections.length > 0) {
    let face = detections[0];
    let faceWidth = face.alignedRect._box._width;

    // Scale the image based on detected face size
    let imgSize = map(faceWidth, 50, 200, 100, 400, true); // Adjust these values based on your testing
    image(
      img,
      width / 2 - imgSize / 2,
      height / 2 - imgSize / 2,
      imgSize,
      imgSize
    );
  }
}

let video;
let faceapi;
let detections = [];

function setup() {
    createCanvas(640, 480);
    video = createCapture(VIDEO);
    video.size(width, height);
    video.hide();

    const detection_options = {
        withLandmarks: true,
        withDescriptors: false
    };
    faceapi = ml5.faceApi(video, detection_options, modelReady);
}

function modelReady() {
    console.log("FaceAPI Model Loaded");
    faceapi.detect(gotResults);
}

function gotResults(err, result) {
    if (err) {
        console.error(err);
        return;
    }
    detections = result;
    faceapi.detect(gotResults);
}

function draw() {
    image(video, 0, 0, width, height);
    if (detections) {
        for (let i = 0; i < detections.length; i++) {
            const {alignedRect} = detections[i];
            const {x, y, width, height} = alignedRect._box;
            noFill();
            stroke(255, 0, 0);
            strokeWeight(2);
            rect(x, y, width, height);
        }
    }
}
